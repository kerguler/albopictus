void rng_setup(char*);
void rng_setup_seed(unsigned int, char*);
void rng_destroy();
double rng_exponential(const double);
