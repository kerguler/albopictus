void rng_setup();
void rng_setup_seed(unsigned int seed);
void rng_destroy();
double rng_exponential(const double mu);
