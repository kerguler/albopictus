#ifndef SPOP_H
#define SPOP_H

#define DPOP_EPS 1e-14

typedef double (*prob_func)(unsigned int, double, double, double);

typedef union {
  unsigned int i;
  double d;
} sdnum;

typedef struct individual_st
{
  unsigned int age;
  sdnum number;
  struct individual_st *next;
} *individual_data;

typedef struct population_st
{
  individual_data individual;
  sdnum size;
  sdnum dead;
  sdnum developed;
  unsigned char gamma_mode;
  unsigned char stochastic;
} *spop;

#define spop_add(s,age,number) {               \
    if ((number)>DPOP_EPS) {                    \
      sdnum tmp;                                \
      if ((s)->stochastic)                      \
        tmp.i = (int)(number);                  \
      else                                      \
        tmp.d = (double)(number);               \
      spop_sdadd((s),(age),tmp);               \
    }                                           \
  }

spop spop_init(unsigned char, unsigned char);
void spop_sdadd(spop, unsigned int, sdnum);
void spop_print(spop);
void spop_remove_next(spop, individual_data);
void spop_empty(spop);
void spop_destroy(spop*);
void spop_kill(spop, double);

prob_func assign_prob_func(spop, double, double, double);

void spop_iterate(spop, double, double, double, double, double, double);

#endif
